fx_version 'adamant'
game 'gta5'